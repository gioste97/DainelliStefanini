//
// Created by Stefano on 15/11/2017.
//

#include "Weapon.h"

int Weapon::attack() {// attack si intende il danno effettivo da aggiungere il danno damage del tipo di materiale


}

