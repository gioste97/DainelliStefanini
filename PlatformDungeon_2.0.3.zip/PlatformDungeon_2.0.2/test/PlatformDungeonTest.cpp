#include "gtest/gtest.h"
#include "../GameCharacter.h"
#include <iostream>
#include <SFML/Graphics.hpp>
#include "../Hero.h"
#include "../Enemy.h"

int main() {

//Test Map load. A peace of map load.
 // create the tilemap from the level definition
  const int level[] =
            {
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0,
                    0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0,
                    0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0,
                    0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0,
                    0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0,
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
            };

    TileMap map;
    if (!map.load("Tile2.jpeg", sf::Vector2u(32, 32), level, 58, 33))
        std::cout << "Texture Error, Map error to load" << std::endl;
    else
        std::cout << "Map, load with success" << std::endl;

//Test collision. A box that is collid with the floor;
    // Create window
    sf::RenderWindow window(sf::VideoMode(800, 600), "SFML");
    // Limit frame-rate
    window.setFramerateLimit(60);

    // Keep track of the frametime
    sf::Clock frametime;

    // Big floor
    sf::RectangleShape floor(sf::Vector2f(800.f, 40.f));
    floor.setPosition(0.f, 560.f);
    floor.setFillColor(sf::Color(10, 180, 30));

    // Movable player
    sf::RectangleShape player(sf::Vector2f(40.f, 40.f));
    player.setOrigin(20.f, 20.f);
    player.setPosition(400.f, 40.f);
    player.setFillColor(sf::Color(10, 30, 180));

    // Player speed
    sf::Vector2f speed(0.f, 0.f);

    // Gravity value
    const float gravity = 980.f;

    // Check if we're touching any floor/box
    bool touching = false;

    while (window.isOpen()) {
        // Get delta time for frame-rate depended movement
        float dt = frametime.restart().asSeconds();

        // Event handling
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Slow down horizontal speed
        if (speed.x > 6.f)
            speed.x -= 3.f;
        else if (speed.x < -6.f)
            speed.x += 3.f;
        else
            speed.x = 0.f;

        // Adjust vertical speed
        if (touching)
            speed.y = gravity;
        else if (speed.y < gravity)
            speed.y += 10.f;
        else if (speed.y > gravity)
            speed.y = gravity;

        // Horizontal movement
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            speed.x = 0.f;
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left))
            speed.x = -120.f;
        else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right))
            speed.x = 120.f;

        // Move the player
        player.setPosition(player.getPosition().x + speed.x * dt, player.getPosition().y + speed.y * dt);

        // Check collision & position adjustment
        if (floor.getGlobalBounds().intersects(player.getGlobalBounds())) // Floor
        {
            player.setPosition(player.getPosition().x, floor.getPosition().y - player.getOrigin().y);
            touching = true;
        } else // We're not colliding
            touching = false;

        // Render
        window.clear();
        window.draw(player);
        window.draw(floor);
        window.display();
    }
//Test enemy stronger than Hero
Hero *Giovanni = Hero::GetHero();//created by factoryH
Enemy *Stefano = Enemy::GetEnemy(); //created by factory
     int damoHero = 0;
    int damoEnemy = 0;
    int done = 0;
    int c = 0;

    for (int hit = 0; hit < Stefano->getHp() || hit < Giovanni->getHp(); hit++) {

        do {
            c = getchar();
            putchar(c);
        } while (c != ' ');

        damoHero = Giovanni->fight(*Stefano);
        damoEnemy = (Stefano->fightHero(*Giovanni))*10; //moltiplico il danno dell'enemy per 10 per farlo + forte

        if (damoHero)
            std::cout <<" Enemy hit: " << damoHero << std::endl;
        if (Stefano->getHp() > 0)
            std::cout << "Healty Point of Enemy"<<": "<< Stefano->getHp() << std::endl;
        else {
            std::cout << "Healty Point of Enemy"<<": "<< 0 << std::endl;
        }
        if (Stefano->getHp() <= 0) {
            std::cout << "\n"<<"Enemy is dead" << std::endl;
            return 0;
        }

        if (damoEnemy && done == 0)
            std::cout << "Hero hit: " << damoEnemy << std::endl;
        if (Giovanni->getHp() > 0 && done == 0)
            std::cout << "Healty Point of Your Hero " << Giovanni->getHp()<< std::endl;
        else if (done == 0) {
            std::cout << "Healty Point of Your Hero " << 0 << std::endl;
            std::cout << "\nYour Hero is dead" << std::endl;
            return 0;
        }
    }
    return 0;
}


