//
// Created by Stefano on 22/11/2017.
//

#ifndef PLATFORMDUNGEON_STRATEGY_H
#define PLATFORMDUNGEON_STRATEGY_H


class Strategy {

public:
    virtual int getIncrease();
    virtual int setIncrease();

};


#endif //PLATFORMDUNGEON_STRATEGY_H
