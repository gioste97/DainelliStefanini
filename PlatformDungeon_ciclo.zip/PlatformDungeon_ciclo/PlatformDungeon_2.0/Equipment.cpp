//
// Created by Stefano on 22/11/2017.
//

#include "Equipment.h"
